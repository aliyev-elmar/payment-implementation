<div {{ $attributes->merge(['class' => 'h-full flex flex-col items-center justify-center p-4']) }}>
    <x-pulse::icons.no-pulse class="h-8 w-8 stroke-gray-300 dark:stroke-gray-700" />
    <p class="mt-2 text-sm text-gray-400 dark:text-gray-600">
        No results
    </p>
</div>
