<table {{ $attributes->merge(['class' => 'w-full']) }}>
    {{ $slot }}
</table>
